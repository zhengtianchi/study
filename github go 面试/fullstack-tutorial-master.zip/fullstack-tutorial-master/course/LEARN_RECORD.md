## PART2：学习记录

### 已完成的课程

| 课程                                                         | 进展            |
| ------------------------------------------------------------ | --------------- |
| [SpringBoot+MyBatis搭建迷你小程序教程](https://www.imooc.com/learn/945) | 2018/05/06 完成 |
| [IntelliJ IDEA神器使用技巧](https://www.imooc.com/learn/924) | 2018/05/14 完成 |
| [表严肃讲正则表达式](http://biaoyansu.com/28.x)              | 2018/06/05 完成 |
| [表严肃讲Git](http://biaoyansu.com/27.x)                     | 2018/06/05 完成 |
| [第一个docker化的java应用](https://www.imooc.com/learn/824)  | 2018/06/06 完成 |



### 学习课程

| 课程                                                         | 进展                         |
| ------------------------------------------------------------ | ---------------------------- |
| ★★★刘宇波：玩转数据结构 \| [代码仓库](https://github.com/liuyubobobo/Play-with-Algorithms) \| [学习笔记](course\01 玩转数据结构.md ) | 2018/05/06 学习至 第三章<br> |
| ★刘宇波：玩转算法面试 \| [学习笔记](course/02 玩转算法面试.md) | 计划学习                     |
| ★刘宇波：程序员的内功修炼                                    | 计划学习                     |
| ★★★廖师兄：[Spring Boot企业微信点餐系统](https://coding.imooc.com/class/117.html) \| [学习笔记](course\03 SpringBoot微信点餐.md ) | 2018/05/06 学习至 第五章     |
| [微信授权登录](https://www.imooc.com/learn/713)              |                              |
| [PHP第三方登录—OAuth2.0协议](https://www.imooc.com/learn/557) |                              |
|                                                              |                              |
| Redis从入门到高可用，分布式实践 \| [慕课网](https://coding.imooc.com/class/151.html) | 计划学习                     |
| ZooKeeper分布式专题与Dubbo微服务入门 \| [慕课网](https://coding.imooc.com/class/201.html) | 计划学习                     |
|                                                              |                              |
| [Redis入门](https://www.imooc.com/learn/839)                 | 计划学习                     |
|                                                              |                              |
| HTTP协议原理+实践 Web开发工程师必学                          | 正在学习                     |
| ★Nginx入门到实践 \| [慕课网](https://coding.imooc.com/class/evaluation/121.html#Anchor) \| [学习笔记](course\04 Nginx从入门到实战.md) | 正在学习                     |
| 系统学习Docker 践行DevOps理念                                | 正在学习                     |




下载地址：[Navicat Premium 12安装包（附破解工具）](https://download.csdn.net/download/u012104219/10434335)



**注意：**
	PatchNavicat.exe可能报毒，但是安全的破解文件，介意的小伙伴请慎重下载！

**破解方式：**
	打开PatchNavicat.exe
	浏览，选定3次，"C:\Program Files\PremiumSoft\Navicat Premium 12\navicat.exe"
	即可破解成功！

so easy...

请不要下载官网的安装包，否则无法破解成功。






idea快速生成实体类Entity（找了半天，自己一步就搞出来了） - CSDN博客
https://blog.csdn.net/hgg923/article/details/53439038






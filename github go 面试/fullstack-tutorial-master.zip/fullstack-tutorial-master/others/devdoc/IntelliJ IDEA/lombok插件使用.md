## lombok插件使用

1.加载pom.xml中的依赖

```xml
<!-- 日志、@Data注解 -->
<dependency>
    <groupId>org.projectlombok</groupId>
    <artifactId>lombok</artifactId>
</dependency>
```



2.`CTRL+ALT+S`打开设置，`Plugins`中search`lombok`安装



3.restart



参考：廖师兄课程`4-2买家类目-dao（下） 02:57`视频
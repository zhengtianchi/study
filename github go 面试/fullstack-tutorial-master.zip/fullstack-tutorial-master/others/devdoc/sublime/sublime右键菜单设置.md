将Sublime Text 添加到鼠标右键菜单的教程方法 - Michael_翔 - 博客园
https://www.cnblogs.com/michael-xiang/p/4831970.html


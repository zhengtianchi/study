centos安装redis

**yum安装**

`yum install redis`



**启动redis**

启动Redis服务：使用`service redis start`命令启动redis服务端。 



**打开redis客户端**

使用命令：`redis-cli` 即可打开客户





`service redis start`





redis设置密码

如何给redis设置密码 - CSDN博客
https://blog.csdn.net/qq_35357001/article/details/56835919




## 操作系统

- 进程调度算法



## 算法

- 写代码，判断链表是否中心对称，要求时间O(N)，空间O(1)，解释思路+口头跑testcase。（8分钟左右）



## 补充知识点

- 设计一个线程池
- mybatis二级缓存如何设计
- CAS如何实现
- Linux diff命令
- 函数式编程 Lambda 
- rpc
- 消息队列
- 分布式



## 待整理好文

高效运维：TCP连接的状态详解以及故障排查
https://mp.weixin.qq.com/s/hnstE9WgvShE3qZcWWbUJQ



## 技术点

- RPC

分布式系统设计与开发

负载均衡技术

系统容灾设计

高可用系统







## README

- 网络 I/O 模型

　　4 种网络 IO 模型、select、poll、epoll
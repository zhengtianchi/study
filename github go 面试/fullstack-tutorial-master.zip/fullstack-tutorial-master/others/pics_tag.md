
# 文档格式

## 1. 图片格式



<div align="center"> <img src="../pics/hash-to-badlink.png" width=""/></div><br/>

<div align="center"> <img src="pics/concurrent_and_parallel.png" width=""/></div><br/>

<div align="center"><img src="" width=""/></div><br/>

<div align="center"><img src="" width=""/></div>









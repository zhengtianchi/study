# 深入浅出 Kafka（七）监控

Kafka Monitor，Kafka Manager


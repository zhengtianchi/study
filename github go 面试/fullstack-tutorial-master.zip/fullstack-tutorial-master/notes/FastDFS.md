# FastDFS

手把手教你搭建分布式文件存储系统



用FastDFS一步步搭建文件管理系统 - bojiangzhou - 博客园
https://www.cnblogs.com/chiangchou/p/fastdfs.html


# 前言





参考仓库：

- [springmvc-mybatis-learning](https://github.com/brianway/springmvc-mybatis-learning)

1. Spring、SpringMVC原理、流程

1. Mybatis原理
2. Hibernate了解吗，Mybatis和Hibernate的区别
# fullstack tutorial

> 全栈开发指南，架构师成长之路

<!-- - 后台技术栈/全栈开发/架构师之路，秋招/春招/校招/面试 -->
- 操作系统、计算机网络、数据库与算法
- Java技术栈、微服务、分布式系统架构
- Docker、Git工作流、正则表达式
- from zero to hero

<span id="la_19815069"></span>

[Get Started](introduction)
[GitHub](https://github.com/frank-lam/fullstack-tutorial)

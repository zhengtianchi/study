package main

func main() {

}

func maxSubstringSum(arr []int) int {

}

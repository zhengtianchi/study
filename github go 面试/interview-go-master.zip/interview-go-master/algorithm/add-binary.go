package main

func main() {

}

/**
 *
 * @param a string字符串
 * @param b string字符串
 * @return string字符串
 */
func addBinary(a string, b string) string {
	// write code here
	return ""
}
